require 'rinruby'
require 'stringio'

def checkPackage(pkgName, installed_packages)
  unless installed_packages =~ /#{pkgName}/
    fail("#{pkgName} R package is missing")
  end
end


def with_captured_stdout
  begin
    old_stdout = $stdout
    $stdout = StringIO.new('','w')
    yield
    $stdout.string
  ensure
    $stdout = old_stdout
  end
end


installed_packages = with_captured_stdout {  R.eval("installed.packages()") }

checkPackage(:randomForest, installed_packages)
checkPackage(:dlm, installed_packages)
checkPackage(:rattle, installed_packages)

